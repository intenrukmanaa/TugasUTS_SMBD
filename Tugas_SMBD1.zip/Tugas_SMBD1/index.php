<?php
// koneksi Database
include("inc_koneksi.php");



$server = "127.0.0.1:3307";
$user = "root";
$pass = "";
$database = "smbd";

// buat koneksi
$koneksi = mysqli_connect($server, $user, $pass, $database) or die(mysqli_error($koneksi));

// jika tombol simpan di klik
if (isset($_POST['bsimpan'])) {

  //  pengujian apakah data akan disimpan atau diedit
  if (isset($_GET['hal']) == "edit") {

    // data akan diedit
    $edit = mysqli_query($koneksi, " UPDATE  pemantauan SET
                                      id_pengukuran= '$_POST[tpengukuran]',
                                      id_suhu= '$_POST[tsuhu]',
                                      id_gas= '$_POST[tgas]',
                                      id_buah= '$_POST[tbuah]',
                                      nilai_gas= '$_POST[tngas]',
                                      nilai_suhu= '$_POST[tnsuhu]',
                                      berat_buah= '$_POST[tbbuah]'
                                    WHERE id_pemantauan = '$_GET[id]'
                                   ");
    //  uji jika edit data berhasil
    if ($edit) {
      echo "<script>
          alert('edit data berhasil');
          document.location='index.php';
    
        </script>";
    } else {
      echo "<script>
          alert('edit data gagal');
          document.location='index.php';
    
        </script>";
    }
  } else {
    // jika bukan edit maka data akan di simpan baru
    // Data akan di simpan adalah data baru
    $simpan = mysqli_query($koneksi, " INSERT INTO pemantauan (id_pengukuran,id_suhu,id_gas,id_buah,nilai_gas,nilai_suhu,berat_buah)
  VALUE('$_POST[tpengukuran]',
        '$_POST[tsuhu]',
        '$_POST[tgas]',
        '$_POST[tbuah]',
        '$_POST[tngas]',
        '$_POST[tnsuhu]',
        '$_POST[tbbuah]')");

    //  uji jika simpan data berhasil
    if ($simpan) {
      echo "<script>
          alert('Simpan data berhasil');
          document.location='index.php';
    
        </script>";
    } else {
      echo "<script>
          alert('Simpan data gagal');
          document.location='index.php';
    
        </script>";
    }

  }


}


// deklarasi variabel untuk menampung data yang akan di edit
$vid_pengukuran = "";
$vid_suhu = "";
$vid_gas = "";
$vid_buah = "";
$vnilai_gas = "";
$vnilai_suhu = "";
$vberat_buah = "";



// pengujian jika tombol edit atau diihapus di klik

if (isset($_GET['hal'])) {

  // pengujian jika edit data
  if ($_GET['hal'] == "edit") {
    // tampilkan data yang akan diedit
    $tampil = mysqli_query($koneksi, "SELECT * FROM pemantauan WHERE id_pemantauan = '$_GET[id]'");
    $data = mysqli_fetch_array($tampil);
    if ($data) {
      // jika data ditemukan maka data ditampung dalam variabel
      $vid_pengukuran = $data['id_pengukuran'];
      $vid_suhu = $data['id_suhu'];
      $vid_gas = $data['id_gas'];
      $vid_buah = $data['id_buah'];
      $vnilai_gas = $data['nilai_gas'];
      $vnilai_suhu = $data['nilai_suhu'];
      $vberat_buah = $data['berat_buah'];
    }

  } else if ($_GET['hal'] == "hapus") {
    // persiapan hapus data
    $hapus = mysqli_query($koneksi, "DELETE FROM pemantauan WHERE id_pemantauan ='$_GET[id]'");

    //  uji jika hapus data berhasil
    if ($hapus) {
      echo "<script>
          alert('hapus data berhasil');
          document.location='index.php';
    
        </script>";
    } else {
      echo "<script>
          alert('hapus data gagal');
          document.location='index.php';
    
        </script>";
    }

  }
}





?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tugas SMBD1</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
  <!-- awal container -->
  <div class="container">
    <div class="mt-5">
      <h3 class="text-center">Data Pemantuan Perubahan Buah<h3>
    </div>
    <!-- awal row -->
    <div class="row" style="font-size:15px;">
      <!-- awal col-md-7 mx-auto -->
      <div class="col-md-7 mx-auto">
        <!-- akhir col-md-7 mx-auto -->
        <!-- awal card -->
        <div class="card ">
          <div class="card-header bg-success text-light">
            Form Input Data Penelitian
          </div>
          <div class="card-body">
            <!--  Awal form -->
            <form method="POST">
              <div class="mb-3">
                <label class="form-label">Id pengukuran</label>
                <input type="text" name="tpengukuran" value="<?= $vid_pengukuran ?>" class="form-control"
                  placeholder="Masukkan id pengukuran">
              </div>
              <div class="mb-3">
                <label class="form-label">Id suhu</label>
                <input type="text" name="tsuhu" value="<?= $vid_suhu ?>" class="form-control"
                  placeholder="Masukkan id suhu">
              </div>
              <div class="mb-3">
                <label class="form-label">Id gas</label>
                <input type="text" name="tgas" value="<?= $vid_gas ?>" class="form-control"
                  placeholder="Masukkan id gas">
              </div>
              <div class="mb-3">
                <label class="form-label">Id buah</label>
                <input type="text" name="tbuah" value="<?= $vid_buah ?>" class="form-control"
                  placeholder="Masukkan id buah">
              </div>

              <div class="mb-3">
                <label class="form-label">nilai gas</label>
                <input type="text" name="tngas" value="<?= $vnilai_gas ?>" class="form-control"
                  placeholder="Masukkan nilai gas">
              </div>
              <div class="mb-3">
                <label class="form-label">nilai suhu</label>
                <input type="text" name="tnsuhu" value="<?= $vnilai_suhu ?>" class="form-control"
                  placeholder="Masukkan nilai suhu">
              </div>
              <div class="row">
                <div class="col">
                  <div class="mb-3">
                    <label class="form-label">Berat buah</label>
                    <input type="text" name="tbbuah" value="<?= $vberat_buah ?>" class="form-control"
                      placeholder="Masukkan berat buah">
                  </div>
                </div>

                <div class="text-center">
                  <hr>
                  <button class=" btn btn-primary" name="bsimpan" type="submit">Simpan Data</button>
                  <button class=" btn btn-danger" name="bhapus" type="reset">Hapus Data</button>
                </div>
              </div>

            </form>
            <!-- Akhir form -->



          </div>
          <div class="card-footer bg-success">
          </div>
        </div>
        <!-- akhir card -->
      </div>
      <!-- akhir col-md-7 mx-auto -->
    </div>
    <!-- akhir row -->

    <div class="card mt-5  mx-auto">
      <div class="card-header bg-success text-light">
        Data Penelitian
      </div>
      <div class="card-body">
        <div class="col-md-6 mx-auto">
          <form method="POST">
            <div class="input-group mb-3">
              <input type="text" name="tcari" value="<?= $_POST['bcari'] ?>" class="form-control"
                placeholder="Masukkan kata kunci">
              <button class="btn btn-primary" name="bcari" type="submit">Cari</button>
              <button class="btn btn-danger" name="breset" type="reset">Reset</button>
            </div>
          </form>
        </div>
        <table class=" table table-striped table-hover table-bordered" style="font-size:14px;">
          <tr>
            <th>No.</th>
            <th>Id_pengukuran</th>
            <th>Id_suhu</th>
            <th>Id_gas</th>
            <th>Id_buah</th>
            <th>Nilai gas</th>
            <th>Nilai suhu</th>
            <th>Berat buah</th>
            <th>Aksi</th>
          </tr>

          <?php
          // persiapan menampilkan data
          $no = 1;

          // untuk mencari data
          // jika tombol  cari di klik
          if (isset($_POST['tcari'])) {
            //menampilkan data yang dicari
            $keyword = $_POST['bcari'];
            $q = "SELECT * FROM pemantauan WHERE id_suhu like '%$keyword%' or id_gas like '%$keyword%' order by id_pemantauan desc";
          } else {
            $q = "SELECT * FROM pemantauan order by id_pemantauan desc";
          }


          $tampil = mysqli_query($koneksi, $q);
          while ($data = mysqli_fetch_array($tampil)):

            ?>
            <tr>
              <td>
                <?= $no++ ?>
              </td>
              <td>
                <?= $data['id_pengukuran'] ?>
              </td>
              <td>
                <?= $data['id_suhu'] ?>
              </td>
              <td>
                <?= $data['id_gas'] ?>
              </td>
              <td>
                <?= $data['id_buah'] ?>
              </td>
              <td>
                <?= $data['nilai_gas'] ?>
              </td>
              <td>
                <?= $data['nilai_suhu'] ?>
              </td>
              <td>
                <?= $data['berat_buah'] ?>
              </td>
              <td>
                <a href="index.php?hal=edit&id=<?= $data['id_pemantauan'] ?>" class="btn btn-primary">Edit</a>


                <a href="index.php?hal=hapust&id=<?= $data['id_pemantauan'] ?>" class=" btn btn-danger"
                  onclick="return confirm('Apakah anda yakin akan menghapus data ini')">Hapus</a>
              </td>
            </tr>
          <?php endwhile; ?>
        </table>
      </div>
      <div class="card-footer bg-success">
      </div>
    </div>


  </div>
  <p><a href="logout.php">Keluar dari Form</a></p>

  <!-- akhir container -->






  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script>
</body>

</html>