<?php
$server = "127.0.0.1:3307";
$user = "root";
$pass = "";
$database = "rumah_sakit";
// koneksi

$koneksi = mysqli_connect($server, $user, $pass, $database);
if (!$koneksi) {
                die("koneksi gagal");
}
?>